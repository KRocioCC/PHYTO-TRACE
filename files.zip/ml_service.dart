import 'dart:convert';
import 'dart:io';
import 'package:flutter/services.dart';
import 'package:image/image.dart' as img;
import 'package:tflite_flutter/tflite_flutter.dart';

class MLService {
  Interpreter? _interpreter;
  List<String> _labels = [];
  Map<String, dynamic> _recommendations = {};
  bool _ready = false;

  bool get isReady => _ready;

  Future<void> init() async {
    // Cargar modelo
    _interpreter = await Interpreter.fromAsset(
      'assets/phyto_trace_corn.tflite',
    );

    // Cargar etiquetas
    final labelsRaw = await rootBundle.loadString('assets/corn_labels.txt');
    _labels = labelsRaw
        .trim()
        .split('\n')
        .map((l) => l.trim())
        .where((l) => l.isNotEmpty)
        .toList();

    // Cargar recomendaciones
    final recoRaw =
        await rootBundle.loadString('assets/corn_recommendations.json');
    _recommendations = jsonDecode(recoRaw) as Map<String, dynamic>;

    _ready = true;
  }

  /// Clasifica la imagen en [imagePath].
  /// Retorna: { 'label', 'confidence', 'recommendation', 'allScores' }
  Future<Map<String, dynamic>> classify(String imagePath) async {
    if (!_ready) await init();

    // 1. Leer imagen y redimensionar a 224x224
    final bytes = await File(imagePath).readAsBytes();
    final original = img.decodeImage(bytes);
    if (original == null) throw Exception('No se pudo decodificar la imagen');

    final resized = img.copyResize(original, width: 224, height: 224);

    // 2. Construir tensor float32 [1, 224, 224, 3] normalizado a [0,1]
    final inputTensor = List.generate(
      1,
      (_) => List.generate(
        224,
        (y) => List.generate(
          224,
          (x) {
            final pixel = resized.getPixel(x, y);
            return [
              pixel.r / 255.0,
              pixel.g / 255.0,
              pixel.b / 255.0,
            ];
          },
        ),
      ),
    );

    // 3. Output [1, numClases]
    final numClases = _labels.length;
    final outputTensor =
        List.filled(numClases, 0.0).reshape([1, numClases]);

    // 4. Inferencia
    _interpreter!.run(inputTensor, outputTensor);

    // 5. Encontrar clase con mayor score
    final scores = List<double>.from(outputTensor[0] as List);
    double maxScore = -1;
    int maxIdx = 0;
    for (int i = 0; i < scores.length; i++) {
      if (scores[i] > maxScore) {
        maxScore = scores[i];
        maxIdx = i;
      }
    }

    final label = maxIdx < _labels.length ? _labels[maxIdx] : 'Desconocido';
    final recommendation =
        _recommendations[label]?.toString() ??
        'Consulte a un técnico agrícola.';

    // Todos los scores para mostrar ranking
    final allScores = <Map<String, dynamic>>[];
    for (int i = 0; i < scores.length && i < _labels.length; i++) {
      allScores.add({'label': _labels[i], 'score': scores[i]});
    }
    allScores.sort((a, b) =>
        (b['score'] as double).compareTo(a['score'] as double));

    return {
      'label': label,
      'confidence': maxScore,
      'recommendation': recommendation,
      'allScores': allScores,
    };
  }

  void dispose() {
    _interpreter?.close();
    _ready = false;
  }
}
